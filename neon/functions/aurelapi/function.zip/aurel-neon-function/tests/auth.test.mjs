import test from 'node:test';
import assert from 'node:assert/strict';
import { generateKeyPairSync, sign } from 'node:crypto';
import { verifyNeonToken, mapOrganizationRole, canReview, validatePropertyInput } from '../auth.mjs';

const issuer = 'https://ep-blue-firefly-b9pe23jg.neonauth.c-7.eu-central-1.aws.neon.tech/aurel/auth';
const userId = '453253c5-2690-4155-a455-5c681d1b5337';
const { publicKey, privateKey } = generateKeyPairSync('ed25519');
const jwk = { ...publicKey.export({ format: 'jwk' }), kid: 'test-key', use: 'sig', alg: 'EdDSA' };

function token(overrides = {}, key = privateKey) {
  const header = Buffer.from(JSON.stringify({ alg: 'EdDSA', typ: 'JWT', kid: 'test-key' })).toString('base64url');
  const payload = Buffer.from(JSON.stringify({ sub: userId, iss: issuer, exp: 2_000_000_000, aud: 'authenticated', ...overrides })).toString('base64url');
  const input = `${header}.${payload}`;
  return `${input}.${sign(null, Buffer.from(input), key).toString('base64url')}`;
}

const fetchImpl = async () => new Response(JSON.stringify({ keys: [jwk] }), { status: 200, headers: { 'content-type': 'application/json' } });

test('accepts a valid EdDSA Neon Auth token for the configured issuer', async () => {
  assert.equal(await verifyNeonToken(token(), { jwksUrl: `${issuer}/.well-known/jwks.json`, issuer, fetchImpl, now: 1_900_000_000 }), userId);
});

test('rejects an expired token', async () => {
  assert.equal(await verifyNeonToken(token({ exp: 1_800_000_000 }), { jwksUrl: `${issuer}/.well-known/jwks.json`, issuer, fetchImpl, now: 1_900_000_000 }), null);
});

test('rejects a token issued by another branch', async () => {
  assert.equal(await verifyNeonToken(token({ iss: 'https://other.neonauth.example/auth' }), { jwksUrl: `${issuer}/.well-known/jwks.json`, issuer, fetchImpl, now: 1_900_000_000 }), null);
});

test('rejects unsupported algorithms and unexpected audiences', async () => {
  const wrongAud = token({ aud: 'https://another-api.example' });
  assert.equal(await verifyNeonToken(wrongAud, { jwksUrl: `${issuer}/.well-known/jwks.json`, issuer, fetchImpl, now: 1_900_000_000 }), null);
});

test('maps managed organization roles to least-privilege application roles', () => {
  assert.equal(mapOrganizationRole('owner'), 'owner');
  assert.equal(mapOrganizationRole('admin'), 'admin');
  assert.equal(mapOrganizationRole('member'), 'broker');
  assert.equal(mapOrganizationRole('unknown'), null);
  assert.equal(canReview('owner'), true);
  assert.equal(canReview('admin'), true);
  assert.equal(canReview('broker'), false);
});

test('validates property payloads without coercing unsafe prices', () => {
  const valid = { title: 'Verified coastal villa', description: 'A sufficiently detailed description of the property and its location.', country_code: 'pt', city: 'Lisbon', property_type: 'villa', currency: 'eur', asking_price_minor: '120000000' };
  assert.equal(validatePropertyInput(valid).country_code, 'PT');
  assert.equal(validatePropertyInput({ ...valid, asking_price_minor: '1e9' }), null);
  assert.equal(validatePropertyInput({ ...valid, country_code: 'PRT' }), null);
});
