import { createPublicKey, verify as verifySignature } from 'node:crypto';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const jwksCache = new Map();

function decodePart(part) {
  return JSON.parse(Buffer.from(part, 'base64url').toString('utf8'));
}

export async function verifyNeonToken(token, {
  jwksUrl,
  issuer,
  fetchImpl = fetch,
  now = Math.floor(Date.now() / 1000),
}) {
  if (typeof token !== 'string' || token.length > 16384) return null;
  if (!jwksUrl?.startsWith('https://') || !issuer?.startsWith('https://')) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;

  let header;
  let claims;
  try {
    header = decodePart(parts[0]);
    claims = decodePart(parts[1]);
  } catch {
    return null;
  }
  if (header.alg !== 'EdDSA' || typeof header.kid !== 'string' || header.kid.length > 256) return null;
  if (claims.iss !== issuer || !UUID_RE.test(claims.sub ?? '')) return null;
  if (!Number.isInteger(claims.exp) || claims.exp <= now) return null;
  if (claims.nbf !== undefined && (!Number.isInteger(claims.nbf) || claims.nbf > now + 30)) return null;
  const audiences = claims.aud === undefined ? [] : (Array.isArray(claims.aud) ? claims.aud : [claims.aud]);
  if (audiences.length && !audiences.some((aud) => aud === 'authenticated' || aud === issuer)) return null;

  let jwks = jwksCache.get(jwksUrl);
  if (!jwks || jwks.expiresAt <= Date.now()) {
    try {
      const response = await fetchImpl(jwksUrl, { signal: AbortSignal.timeout(5000) });
      if (!response.ok) return null;
      const body = await response.json();
      if (!Array.isArray(body.keys)) return null;
      jwks = { keys: body.keys, expiresAt: Date.now() + 5 * 60 * 1000 };
      jwksCache.set(jwksUrl, jwks);
    } catch {
      return null;
    }
  }
  if (!Array.isArray(jwks.keys)) return null;
  const jwk = jwks.keys.find((key) => key.kid === header.kid && key.kty === 'OKP' && key.crv === 'Ed25519' && typeof key.x === 'string' && (key.use === undefined || key.use === 'sig'));
  if (!jwk) return null;

  try {
    const publicKey = createPublicKey({ key: { kty: 'OKP', crv: 'Ed25519', x: jwk.x }, format: 'jwk' });
    const valid = verifySignature(null, Buffer.from(`${parts[0]}.${parts[1]}`), publicKey, Buffer.from(parts[2], 'base64url'));
    return valid ? claims.sub : null;
  } catch {
    return null;
  }
}

export function mapOrganizationRole(role) {
  if (role === 'owner') return 'owner';
  if (role === 'admin') return 'admin';
  if (role === 'member') return 'broker';
  return null;
}

export function canReview(role) {
  return role === 'owner' || role === 'admin';
}

export function validatePropertyInput(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return null;
  const title = typeof input.title === 'string' ? input.title.trim() : '';
  const description = typeof input.description === 'string' ? input.description.trim() : '';
  const countryCode = typeof input.country_code === 'string' ? input.country_code.trim().toUpperCase() : '';
  const city = typeof input.city === 'string' ? input.city.trim() : '';
  const propertyType = typeof input.property_type === 'string' ? input.property_type : '';
  const currency = typeof input.currency === 'string' ? input.currency.trim().toUpperCase() : '';
  const price = input.asking_price_minor == null ? null : String(input.asking_price_minor);
  const types = new Set(['apartment', 'house', 'villa', 'penthouse', 'land', 'commercial', 'other']);
  if (title.length < 5 || title.length > 180) return null;
  if (description.length < 20 || description.length > 12000) return null;
  if (!/^[A-Z]{2}$/.test(countryCode) || city.length < 2 || city.length > 120) return null;
  if (!types.has(propertyType) || !/^[A-Z]{3}$/.test(currency)) return null;
  if (price !== null && !/^[1-9][0-9]{0,14}$/.test(price)) return null;
  return { title, description, country_code: countryCode, city, property_type: propertyType, currency, asking_price_minor: price };
}
