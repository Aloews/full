import { createHash } from 'node:crypto';
import { Pool } from 'pg';
import { verifyNeonToken, mapOrganizationRole, canReview, validatePropertyInput } from './auth.mjs';

const DATABASE_URL = process.env.DATABASE_URL;
const AUTH_BASE_URL = process.env.NEON_AUTH_BASE_URL;
const JWKS_URL = process.env.NEON_AUTH_JWKS_URL;
const ALLOWED_ORIGINS = new Set((process.env.AUREL_ALLOWED_ORIGINS ?? '').split(',').map((x) => x.trim()).filter(Boolean));
const ENQUIRIES_ENABLED = process.env.AUREL_ENQUIRY_ENABLED === 'true';
if (!DATABASE_URL || !AUTH_BASE_URL || !JWKS_URL) throw new Error('DATABASE_URL, NEON_AUTH_BASE_URL and NEON_AUTH_JWKS_URL are required');

const pool = new Pool({ connectionString: DATABASE_URL, max: 5, idleTimeoutMillis: 30000, connectionTimeoutMillis: 5000 });
pool.on('error', (error) => console.error('database_idle_client_error', error.message));

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const EVIDENCE_TYPES = new Set(['ownership', 'mandate', 'source_listing', 'price_confirmation', 'media_rights', 'inspection', 'other']);
const MAX_BODY_BYTES = 64 * 1024;

function response(status, body, headers = {}) {
  return Response.json(body, { status, headers });
}

function corsHeaders(request) {
  const origin = request.headers.get('origin');
  if (!origin || !ALLOWED_ORIGINS.has(origin)) return {};
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type, X-Aurel-Organization-Id',
    'Access-Control-Max-Age': '600',
    'Vary': 'Origin',
  };
}

function withCors(result, headers) {
  const merged = new Headers(result.headers);
  for (const [key, value] of Object.entries(headers)) merged.set(key, value);
  return new Response(result.body, { status: result.status, statusText: result.statusText, headers: merged });
}

async function readJson(request) {
  const declared = Number(request.headers.get('content-length') ?? '0');
  if (declared > MAX_BODY_BYTES) return { error: response(413, { error: 'payload_too_large' }) };
  const bytes = await request.arrayBuffer();
  if (bytes.byteLength > MAX_BODY_BYTES) return { error: response(413, { error: 'payload_too_large' }) };
  try {
    const parsed = JSON.parse(new TextDecoder().decode(bytes));
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return { error: response(400, { error: 'invalid_json_object' }) };
    return { value: parsed };
  } catch {
    return { error: response(400, { error: 'invalid_json' }) };
  }
}

async function appTransaction(work, organizationId = null) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('SET LOCAL ROLE aurel_app');
    if (organizationId) await client.query("SELECT set_config('app.organization_id', $1, true)", [organizationId]);
    const result = await work(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}

async function authenticate(request) {
  const authHeader = request.headers.get('authorization') ?? '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : '';
  if (!token) return { error: response(401, { error: 'unauthorized' }) };
  const organizationId = request.headers.get('x-aurel-organization-id') ?? '';
  if (!UUID_RE.test(organizationId)) return { error: response(400, { error: 'organization_required' }) };
  const userId = await verifyNeonToken(token, { jwksUrl: JWKS_URL, issuer: AUTH_BASE_URL });
  if (!userId) return { error: response(401, { error: 'invalid_token' }) };
  try {
    const membership = await appTransaction(async (client) => {
      const result = await client.query(
        'SELECT o.id, o.name, m.role FROM neon_auth.member m JOIN neon_auth.organization o ON o.id = m."organizationId" WHERE m."userId" = $1 AND m."organizationId" = $2',
        [userId, organizationId],
      );
      const row = result.rows[0];
      if (!row) return null;
      const role = mapOrganizationRole(row.role);
      if (!role) return null;
      await client.query('INSERT INTO organizations (id, name) VALUES ($1, $2) ON CONFLICT (id) DO NOTHING', [organizationId, row.name]);
      return { userId, organizationId, role };
    });
    return membership ? { auth: membership } : { error: response(403, { error: 'organization_membership_required' }) };
  } catch (error) {
    console.error('auth_membership_lookup_failed', error.message);
    return { error: response(503, { error: 'authorization_unavailable' }) };
  }
}

function requireString(value, min, max) {
  if (typeof value !== 'string') return null;
  const text = value.trim();
  return text.length >= min && text.length <= max ? text : null;
}

async function rateLimit(client, scope, rawKey, maxPerHour) {
  const keyHash = createHash('sha256').update(rawKey).digest('hex');
  const result = await client.query(
    `INSERT INTO property_enquiry_rate_limits (scope, key_hash, window_started_at, request_count, last_seen_at)
     VALUES ($1, $2, now(), 1, now())
     ON CONFLICT (scope, key_hash) DO UPDATE SET
       request_count = CASE WHEN property_enquiry_rate_limits.window_started_at < now() - interval '1 hour' THEN 1 ELSE property_enquiry_rate_limits.request_count + 1 END,
       window_started_at = CASE WHEN property_enquiry_rate_limits.window_started_at < now() - interval '1 hour' THEN now() ELSE property_enquiry_rate_limits.window_started_at END,
       last_seen_at = now()
     RETURNING request_count`,
    [scope, keyHash],
  );
  return Number(result.rows[0].request_count) <= maxPerHour;
}

async function route(request) {
  const url = new URL(request.url);
  const path = url.pathname.replace(/\/+$/, '') || '/';
  const method = request.method.toUpperCase();

  if (method === 'OPTIONS') return new Response(null, { status: 204 });
  if (method === 'GET' && (path === '/health' || path === '/ready')) {
    try {
      await pool.query('SELECT 1');
      return response(200, { ok: true, service: 'aurel-api', branch: process.env.NEON_BRANCH ?? 'unknown' });
    } catch {
      return response(503, { ok: false, error: 'database_unavailable' });
    }
  }

  if (method === 'GET' && path === '/public/properties') {
    const limit = Math.min(Math.max(Number(url.searchParams.get('limit') ?? 24) || 24, 1), 50);
    const country = url.searchParams.get('country')?.toUpperCase() ?? null;
    const city = url.searchParams.get('city') ?? null;
    const propertyType = url.searchParams.get('type') ?? null;
    const result = await appTransaction((client) => client.query(
      `SELECT id, title, description, country_code, city, property_type, currency, asking_price_minor, verified_at
       FROM properties WHERE visibility = 'public' AND verification_state = 'verified'
         AND ($1::char(2) IS NULL OR country_code = $1)
         AND ($2::text IS NULL OR city ILIKE $2)
         AND ($3::text IS NULL OR property_type = $3)
       ORDER BY verified_at DESC NULLS LAST, created_at DESC LIMIT $4`,
      [country, city ? `%${city}%` : null, propertyType, limit],
    ));
    return response(200, { items: result.rows });
  }

  const publicDetail = path.match(/^\/public\/properties\/([0-9a-f-]{36})$/i);
  if (method === 'GET' && publicDetail) {
    if (!UUID_RE.test(publicDetail[1])) return response(404, { error: 'not_found' });
    const result = await appTransaction((client) => client.query(
      `SELECT id, title, description, country_code, city, property_type, currency, asking_price_minor, verified_at
       FROM properties WHERE id = $1 AND visibility = 'public' AND verification_state = 'verified'`,
      [publicDetail[1]],
    ));
    return result.rows[0] ? response(200, { item: result.rows[0] }) : response(404, { error: 'not_found' });
  }

  const enquiryMatch = path.match(/^\/public\/properties\/([0-9a-f-]{36})\/enquiries$/i);
  if (method === 'POST' && enquiryMatch) {
    if (!ENQUIRIES_ENABLED) return response(503, { error: 'enquiry_intake_not_enabled' });
    const propertyId = enquiryMatch[1];
    if (!UUID_RE.test(propertyId)) return response(404, { error: 'not_found' });
    const parsed = await readJson(request);
    if (parsed.error) return parsed.error;
    const name = requireString(parsed.value.name, 2, 120);
    const email = requireString(parsed.value.email, 5, 254)?.toLowerCase();
    const message = requireString(parsed.value.message, 10, 4000);
    if (!name || !email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !message || parsed.value.consent_recorded !== true) return response(400, { error: 'invalid_enquiry' });
    try {
      const result = await appTransaction(async (client) => {
        const property = await client.query("SELECT id FROM properties WHERE id=$1 AND visibility='public' AND verification_state='verified'", [propertyId]);
        if (!property.rows[0]) return { status: 404, body: { error: 'not_found' } };
        const emailAllowed = await rateLimit(client, 'email', email, 3);
        const propertyAllowed = await rateLimit(client, 'property', propertyId, 30);
        await client.query("DELETE FROM property_enquiry_rate_limits WHERE last_seen_at < now() - interval '30 days'");
        if (!emailAllowed || !propertyAllowed) return { status: 429, body: { error: 'rate_limited' } };
        const inserted = await client.query(
          'INSERT INTO property_enquiries (property_id,name,email,message,consent_recorded) VALUES ($1,$2,$3,$4,true) RETURNING id,created_at',
          [propertyId, name, email, message],
        );
        return { status: 201, body: { enquiry: inserted.rows[0] } };
      });
      return response(result.status, result.body);
    } catch (error) {
      console.error('public_enquiry_failed', error.message);
      return response(503, { error: 'enquiry_unavailable' });
    }
  }

  if (!path.startsWith('/api/v1/')) return response(404, { error: 'not_found' });
  const authResult = await authenticate(request);
  if (authResult.error) return authResult.error;
  const auth = authResult.auth;

  if (method === 'GET' && path === '/api/v1/properties') {
    const result = await appTransaction((client) => client.query(
      `SELECT p.*, (SELECT count(*)::int FROM property_evidence e WHERE e.property_id=p.id) AS evidence_count
       FROM properties p ORDER BY p.updated_at DESC LIMIT 100`, []), auth.organizationId);
    return response(200, { items: result.rows });
  }

  if (method === 'POST' && path === '/api/v1/properties') {
    const parsed = await readJson(request);
    if (parsed.error) return parsed.error;
    const input = validatePropertyInput(parsed.value);
    if (!input) return response(400, { error: 'invalid_property' });
    try {
      const item = await appTransaction(async (client) => {
        const result = await client.query(
          `INSERT INTO properties (organization_id,created_by,title,description,country_code,city,property_type,currency,asking_price_minor)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
          [auth.organizationId, auth.userId, input.title, input.description, input.country_code, input.city, input.property_type, input.currency, input.asking_price_minor],
        );
        const property = result.rows[0];
        await client.query('INSERT INTO property_audit_events (organization_id,property_id,actor_id,action,details) VALUES ($1,$2,$3,$4,$5)', [auth.organizationId, property.id, auth.userId, 'property_created', JSON.stringify({ status: 'unverified' })]);
        return property;
      }, auth.organizationId);
      return response(201, { item });
    } catch (error) {
      console.error('property_create_failed', error.message);
      return response(400, { error: 'property_create_failed' });
    }
  }

  const evidenceMatch = path.match(/^\/api\/v1\/properties\/([0-9a-f-]{36})\/evidence$/i);
  if (evidenceMatch && !UUID_RE.test(evidenceMatch[1])) return response(404, { error: 'not_found' });
  if (evidenceMatch && method === 'GET') {
    const result = await appTransaction((client) => client.query(
      'SELECT id,property_id,evidence_type,source_url,reference_code,note,observed_at,created_at,added_by FROM property_evidence WHERE property_id=$1 ORDER BY created_at DESC',
      [evidenceMatch[1]],
    ), auth.organizationId);
    return response(200, { items: result.rows });
  }
  if (evidenceMatch && method === 'POST') {
    const parsed = await readJson(request);
    if (parsed.error) return parsed.error;
    const type = parsed.value.evidence_type;
    const note = requireString(parsed.value.note, 10, 2000);
    const sourceUrl = parsed.value.source_url == null ? null : requireString(parsed.value.source_url, 9, 2048);
    const referenceCode = parsed.value.reference_code == null ? null : requireString(parsed.value.reference_code, 1, 180);
    const observedAt = typeof parsed.value.observed_at === 'string' && !Number.isNaN(Date.parse(parsed.value.observed_at)) ? new Date(parsed.value.observed_at).toISOString() : null;
    if (!EVIDENCE_TYPES.has(type) || !note || (sourceUrl && !sourceUrl.startsWith('https://')) || (parsed.value.source_url != null && !sourceUrl) || (parsed.value.reference_code != null && !referenceCode) || !observedAt) return response(400, { error: 'invalid_evidence' });
    try {
      const item = await appTransaction(async (client) => {
        const inserted = await client.query(
          `INSERT INTO property_evidence (organization_id,property_id,added_by,evidence_type,source_url,reference_code,note,observed_at)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
          [auth.organizationId, evidenceMatch[1], auth.userId, type, sourceUrl, referenceCode, note, observedAt],
        );
        await client.query('INSERT INTO property_audit_events (organization_id,property_id,actor_id,action,details) VALUES ($1,$2,$3,$4,$5)', [auth.organizationId, evidenceMatch[1], auth.userId, 'evidence_added', JSON.stringify({ evidence_type: type })]);
        return inserted.rows[0];
      }, auth.organizationId);
      return response(201, { item });
    } catch (error) {
      console.error('evidence_create_failed', error.message);
      return response(400, { error: 'evidence_create_failed' });
    }
  }

  const submitMatch = path.match(/^\/api\/v1\/properties\/([0-9a-f-]{36})\/submit$/i);
  if (submitMatch && method === 'POST') {
    if (!UUID_RE.test(submitMatch[1])) return response(404, { error: 'not_found' });
    try {
      const item = await appTransaction(async (client) => {
        const updated = await client.query(
          `UPDATE properties SET verification_state='in_review',updated_at=now()
           WHERE id=$1 AND verification_state IN ('unverified','rejected','stale') RETURNING *`,
          [submitMatch[1]],
        );
        if (!updated.rows[0]) return null;
        await client.query('INSERT INTO property_audit_events (organization_id,property_id,actor_id,action,details) VALUES ($1,$2,$3,$4,$5)', [auth.organizationId, submitMatch[1], auth.userId, 'submitted_for_review', '{}']);
        return updated.rows[0];
      }, auth.organizationId);
      return item ? response(200, { item }) : response(404, { error: 'not_found_or_invalid_state' });
    } catch (error) {
      console.error('property_submit_failed', error.message);
      return response(400, { error: 'property_submit_failed' });
    }
  }

  if (method === 'GET' && path === '/api/v1/review-queue') {
    if (!canReview(auth.role)) return response(403, { error: 'reviewer_required' });
    const result = await appTransaction((client) => client.query(
      "SELECT * FROM properties WHERE verification_state='in_review' ORDER BY updated_at ASC LIMIT 100", []), auth.organizationId);
    return response(200, { items: result.rows });
  }

  const reviewMatch = path.match(/^\/api\/v1\/properties\/([0-9a-f-]{36})\/review$/i);
  if (reviewMatch && method === 'POST') {
    if (!UUID_RE.test(reviewMatch[1])) return response(404, { error: 'not_found' });
    if (!canReview(auth.role)) return response(403, { error: 'reviewer_required' });
    const parsed = await readJson(request);
    if (parsed.error) return parsed.error;
    const action = parsed.value.action;
    if (!['verify','reject'].includes(action)) return response(400, { error: 'invalid_review_action' });
    try {
      const item = await appTransaction(async (client) => {
        const evidence = await client.query('SELECT count(*)::int AS count FROM property_evidence WHERE property_id=$1', [reviewMatch[1]]);
        if (action === 'verify' && evidence.rows[0].count < 1) return { conflict: true };
        const updated = await client.query(
          `UPDATE properties SET verification_state=$2,reviewed_by=$3,verified_at=$4,visibility=$5,updated_at=now()
           WHERE id=$1 AND verification_state='in_review' AND created_by <> $3 RETURNING *`,
          [reviewMatch[1], action === 'verify' ? 'verified' : 'rejected', auth.userId, action === 'verify' ? new Date() : null, action === 'verify' && parsed.value.publish === true ? 'public' : 'private'],
        );
        if (!updated.rows[0]) return null;
        await client.query('INSERT INTO property_audit_events (organization_id,property_id,actor_id,action,details) VALUES ($1,$2,$3,$4,$5)', [auth.organizationId, reviewMatch[1], auth.userId, action === 'verify' ? 'property_verified' : 'property_rejected', JSON.stringify({ visibility: updated.rows[0].visibility })]);
        return { item: updated.rows[0] };
      }, auth.organizationId);
      if (item?.conflict) return response(409, { error: 'evidence_required' });
      return item?.item ? response(200, item) : response(409, { error: 'review_not_allowed_or_self_review' });
    } catch (error) {
      console.error('property_review_failed', error.message);
      return response(409, { error: 'review_not_allowed_or_evidence_required' });
    }
  }

  return response(404, { error: 'not_found' });
}

export default {
  async fetch(request) {
    const origin = request.headers.get('origin');
    if (origin && !ALLOWED_ORIGINS.has(origin)) return response(403, { error: 'origin_not_allowed' });
    const headers = corsHeaders(request);
    try {
      return withCors(await route(request), headers);
    } catch (error) {
      console.error('unhandled_api_error', error.message);
      return withCors(response(500, { error: 'internal_error' }), headers);
    }
  },
};
