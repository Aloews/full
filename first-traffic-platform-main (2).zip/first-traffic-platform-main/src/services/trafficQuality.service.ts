import { AppDataSource } from '../config/database';
import { TrafficFilter } from '../entities/TrafficFilter';
import { TrafficSource } from '../entities/TrafficSource';
import { FrequencyCap } from '../entities/FrequencyCap';
import { getCache, setCache } from '../config/redis';

const filterRepo = () => AppDataSource.getRepository(TrafficFilter);
const sourceRepo = () => AppDataSource.getRepository(TrafficSource);
const capRepo = () => AppDataSource.getRepository(FrequencyCap);

export interface BidContext {
  domain?: string;
  ip?: string;
  geo?: { country?: string; region?: string };
  device?: { type?: string; os?: string; ua?: string; ifa?: string };
  userId?: string;
  campaignId: string;
  ownerId: string; // campaign owner userId
}

export interface FilterResult {
  allowed: boolean;
  reason?: string;
  qualityScore: number;
}

// ── Load filters from cache or DB ──
async function getFilters(userId: string): Promise<TrafficFilter[]> {
  const cacheKey = `filters:${userId}`;
  const cached = await getCache<TrafficFilter[]>(cacheKey);
  if (cached) return cached;
  const filters = await filterRepo().find({ where: { userId, active: true } });
  await setCache(cacheKey, filters, 30);
  return filters;
}

// ── Main filter engine ──
export async function filterBidRequest(ctx: BidContext): Promise<FilterResult> {
  const filters = await getFilters(ctx.ownerId);
  let qualityScore = 100;

  for (const filter of filters) {
    switch (filter.type) {
      case 'block_domain':
        if (ctx.domain) {
          const blocked: string[] = Array.isArray(filter.value) ? filter.value : [filter.value];
          if (blocked.some((d) => ctx.domain!.includes(d))) {
            return { allowed: false, reason: `Blocked domain: ${ctx.domain}`, qualityScore: 0 };
          }
        }
        break;

      case 'block_ip':
        if (ctx.ip) {
          const blocked: string[] = Array.isArray(filter.value) ? filter.value : [filter.value];
          if (blocked.includes(ctx.ip)) {
            return { allowed: false, reason: `Blocked IP: ${ctx.ip}`, qualityScore: 0 };
          }
        }
        break;

      case 'block_geo':
        if (ctx.geo?.country) {
          const blocked: string[] = Array.isArray(filter.value) ? filter.value : [filter.value];
          if (blocked.includes(ctx.geo.country.toUpperCase())) {
            return { allowed: false, reason: `Blocked geo: ${ctx.geo.country}`, qualityScore: 0 };
          }
        }
        break;

      case 'block_device':
        if (ctx.device?.type) {
          const blocked: string[] = Array.isArray(filter.value) ? filter.value : [filter.value];
          if (blocked.includes(ctx.device.type)) {
            return { allowed: false, reason: `Blocked device type: ${ctx.device.type}`, qualityScore: 0 };
          }
        }
        break;

      case 'block_os':
        if (ctx.device?.os) {
          const blocked: string[] = Array.isArray(filter.value) ? filter.value : [filter.value];
          if (blocked.map((o) => o.toLowerCase()).includes(ctx.device.os!.toLowerCase())) {
            return { allowed: false, reason: `Blocked OS: ${ctx.device.os}`, qualityScore: 0 };
          }
        }
        break;

      case 'max_bot_rate': {
        // Simple UA-based bot detection
        const ua = ctx.device?.ua?.toLowerCase() || '';
        const botPatterns = ['bot', 'crawler', 'spider', 'scraper', 'headless', 'phantom', 'selenium'];
        const isBot = botPatterns.some((p) => ua.includes(p));
        if (isBot) {
          return { allowed: false, reason: 'Bot traffic detected', qualityScore: 0 };
        }
        break;
      }

      case 'min_quality_score': {
        const minScore = Number(filter.value);
        if (qualityScore < minScore) {
          return { allowed: false, reason: `Quality score ${qualityScore} below minimum ${minScore}`, qualityScore };
        }
        break;
      }

      case 'frequency_cap': {
        const deviceId = ctx.device?.ifa || ctx.userId;
        if (deviceId) {
          const maxImpressions = Number(filter.value);
          const windowHours = 24;
          const since = new Date(Date.now() - windowHours * 3600000);

          const count = await capRepo()
            .createQueryBuilder('fc')
            .where('fc.deviceId = :deviceId', { deviceId })
            .andWhere('fc.campaignId = :campaignId', { campaignId: ctx.campaignId })
            .andWhere('fc.createdAt >= :since', { since })
            .getCount();

          if (count >= maxImpressions) {
            return { allowed: false, reason: `Frequency cap reached: ${count}/${maxImpressions} per 24h`, qualityScore };
          }
        }
        break;
      }
    }
  }

  // Score adjustments based on context
  if (!ctx.device?.ifa && !ctx.userId) qualityScore -= 10; // no device ID
  if (!ctx.geo?.country) qualityScore -= 5;                 // no geo
  if (!ctx.domain) qualityScore -= 5;                       // no domain

  return { allowed: true, qualityScore: Math.max(0, qualityScore) };
}

// ── Bid multipliers based on targeting signals ──
export function calculateBidMultipliers(ctx: BidContext, targeting: Record<string, any>): number {
  let multiplier = 1.0;

  // Geo multipliers
  if (ctx.geo?.country && targeting.geoMultipliers) {
    const geoMult = targeting.geoMultipliers[ctx.geo.country.toUpperCase()];
    if (geoMult) multiplier *= geoMult;
  }

  // Device multipliers
  if (ctx.device?.type && targeting.deviceMultipliers) {
    const devMult = targeting.deviceMultipliers[ctx.device.type];
    if (devMult) multiplier *= devMult;
  }

  // OS multipliers
  if (ctx.device?.os && targeting.osMultipliers) {
    const osMult = targeting.osMultipliers[ctx.device.os];
    if (osMult) multiplier *= osMult;
  }

  // Time-of-day multipliers (hour 0-23)
  if (targeting.hourMultipliers) {
    const hour = new Date().getUTCHours();
    const hourMult = targeting.hourMultipliers[hour];
    if (hourMult) multiplier *= hourMult;
  }

  return parseFloat(Math.min(Math.max(multiplier, 0.1), 5.0).toFixed(3));
}

// ── Record impression for frequency capping ──
export async function recordImpression(deviceId: string, campaignId: string): Promise<void> {
  if (!deviceId) return;
  const cap = capRepo().create({ deviceId, campaignId });
  await capRepo().save(cap);
}

// ── Update traffic source quality score ──
export async function updateSourceQuality(
  sourceId: string,
  metrics: { impressions: number; clicks: number; conversions: number; botDetected: boolean }
): Promise<void> {
  const source = await sourceRepo().findOne({ where: { id: sourceId } });
  if (!source) return;

  const ctr = metrics.impressions > 0 ? metrics.clicks / metrics.impressions : 0;
  const convRate = metrics.clicks > 0 ? metrics.conversions / metrics.clicks : 0;

  // Weighted rolling average
  const w = 0.1; // weight for new data
  source.avgCtr = parseFloat((source.avgCtr * (1 - w) + ctr * w).toFixed(4));
  source.avgConvRate = parseFloat((source.avgConvRate * (1 - w) + convRate * w).toFixed(4));
  source.totalImpressions += metrics.impressions;
  source.totalClicks += metrics.clicks;
  source.totalConversions += metrics.conversions;

  if (metrics.botDetected) {
    source.botRate = parseFloat(Math.min(source.botRate + 0.01, 1).toFixed(4));
  }

  // Recalculate quality score
  let score = 100;
  score -= source.botRate * 50;           // bot rate penalty
  score += Math.min(ctr * 1000, 20);      // CTR bonus (max +20)
  score += Math.min(convRate * 500, 20);  // conv rate bonus (max +20)
  score = Math.max(0, Math.min(100, score));

  source.qualityScore = parseFloat(score.toFixed(2));

  // Auto-adjust bid multiplier based on quality
  source.bidMultiplier = parseFloat((0.5 + (score / 100)).toFixed(2)); // 0.5 - 1.5

  // Auto-block if quality drops below 20
  if (score < 20 && source.status === 'active') {
    source.status = 'blocked';
  }

  await sourceRepo().save(source);
}
