import {
  Entity, PrimaryGeneratedColumn, Column,
  ManyToOne, CreateDateColumn, UpdateDateColumn, Index,
} from 'typeorm';
import { User } from './User';

export type FilterType =
  | 'block_domain'
  | 'block_ip'
  | 'block_geo'
  | 'block_device'
  | 'block_os'
  | 'min_quality_score'
  | 'max_bot_rate'
  | 'frequency_cap';

@Entity('traffic_filters')
export class TrafficFilter {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  name!: string;

  @Column({ type: 'enum', enum: [
    'block_domain', 'block_ip', 'block_geo', 'block_device',
    'block_os', 'min_quality_score', 'max_bot_rate', 'frequency_cap',
  ]})
  type!: FilterType;

  @Column('jsonb')
  value!: any; // string | string[] | number depending on type

  @Column({ default: true })
  @Index()
  active!: boolean;

  @Column({ nullable: true, type: 'text' })
  description!: string;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  user!: User;

  @Column()
  @Index()
  userId!: string;

  @CreateDateColumn()
  createdAt!: Date;

  @UpdateDateColumn()
  updatedAt!: Date;
}
