import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  CreateDateColumn,
  Index,
} from 'typeorm';
import { Campaign } from './Campaign';

@Entity('rtb_auctions')
export class RTBAuction {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  @Index()
  campaignId!: string;

  @ManyToOne(() => Campaign, (campaign) => campaign.auctions, { onDelete: 'CASCADE' })
  campaign!: Campaign;

  @Column({ nullable: true })
  creativeId!: string;

  @Column('decimal', { precision: 10, scale: 4 })
  bidPrice!: number;

  @Column('decimal', { precision: 10, scale: 4, nullable: true })
  clearingPrice!: number;

  @Column({ default: false })
  @Index()
  won!: boolean;

  @Column('jsonb', { nullable: true })
  bidRequest!: Record<string, any>;

  @Column('jsonb', { nullable: true })
  bidResponse!: Record<string, any>;

  @CreateDateColumn()
  @Index()
  createdAt!: Date;
}
