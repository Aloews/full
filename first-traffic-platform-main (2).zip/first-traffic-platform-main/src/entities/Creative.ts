import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';
import { User } from './User';

export type CreativeType = 'banner' | 'native' | 'video' | 'push';
export type CreativeStatus = 'pending' | 'generating' | 'ready' | 'failed';
export type GenerationSource = 'description' | 'logo' | 'manual';

@Entity('creatives')
export class Creative {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  name!: string;

  @Column({ type: 'enum', enum: ['banner', 'native', 'video', 'push'], default: 'banner' })
  type!: CreativeType;

  @Column({ type: 'enum', enum: ['pending', 'generating', 'ready', 'failed'], default: 'pending' })
  @Index()
  status!: CreativeStatus;

  @Column({ type: 'enum', enum: ['description', 'logo', 'manual'], default: 'manual' })
  generationSource!: GenerationSource;

  // AI generation input
  @Column({ nullable: true, type: 'text' })
  prompt!: string;

  @Column({ nullable: true })
  logoUrl!: string;

  @Column({ nullable: true, type: 'text' })
  brandDescription!: string;

  // Generated output
  @Column({ nullable: true })
  imageUrl!: string;

  @Column({ nullable: true })
  headline!: string;

  @Column({ nullable: true, type: 'text' })
  bodyText!: string;

  @Column({ nullable: true })
  ctaText!: string;

  @Column({ nullable: true })
  landingUrl!: string;

  // Dimensions
  @Column({ nullable: true })
  width!: number;

  @Column({ nullable: true })
  height!: number;

  // AI metadata
  @Column('jsonb', { nullable: true })
  aiMetadata!: Record<string, any>;

  @Column({ nullable: true, type: 'text' })
  errorMessage!: string;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  user!: User;

  @Column()
  @Index()
  userId!: string;

  @CreateDateColumn()
  createdAt!: Date;

  @UpdateDateColumn()
  updatedAt!: Date;
}
