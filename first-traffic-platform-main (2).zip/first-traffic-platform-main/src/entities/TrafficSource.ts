import {
  Entity, PrimaryGeneratedColumn, Column,
  ManyToOne, CreateDateColumn, UpdateDateColumn, Index,
} from 'typeorm';
import { User } from './User';

@Entity('traffic_sources')
export class TrafficSource {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  name!: string;

  @Column({ nullable: true, type: 'text' })
  description!: string;

  @Column()
  endpoint!: string; // SSP bid request URL

  @Column({ type: 'enum', enum: ['active', 'paused', 'blocked'], default: 'active' })
  @Index()
  status!: string;

  // Quality metrics (updated by scoring engine)
  @Column('decimal', { precision: 5, scale: 2, default: 100 })
  qualityScore!: number; // 0-100

  @Column('decimal', { precision: 5, scale: 4, default: 0 })
  botRate!: number; // 0-1

  @Column('decimal', { precision: 5, scale: 4, default: 0 })
  avgCtr!: number;

  @Column('decimal', { precision: 5, scale: 4, default: 0 })
  avgConvRate!: number;

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  avgCpm!: number;

  @Column({ default: 0 })
  totalImpressions!: number;

  @Column({ default: 0 })
  totalClicks!: number;

  @Column({ default: 0 })
  totalConversions!: number;

  // Bid multiplier: adjust bids for this source (0.5 = bid 50% less, 1.5 = bid 50% more)
  @Column('decimal', { precision: 4, scale: 2, default: 1.0 })
  bidMultiplier!: number;

  @Column('jsonb', { default: {} })
  metadata!: Record<string, any>;

  @ManyToOne(() => User, { onDelete: 'CASCADE' })
  user!: User;

  @Column()
  @Index()
  userId!: string;

  @CreateDateColumn()
  createdAt!: Date;

  @UpdateDateColumn()
  updatedAt!: Date;
}
