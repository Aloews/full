import {
  Entity, PrimaryGeneratedColumn, Column,
  CreateDateColumn, Index,
} from 'typeorm';

@Entity('frequency_caps')
@Index(['deviceId', 'campaignId'])
@Index(['deviceId', 'createdAt'])
export class FrequencyCap {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  @Index()
  deviceId!: string; // from bid request device.ifa or user.id

  @Column()
  @Index()
  campaignId!: string;

  @Column({ default: 1 })
  impressions!: number;

  @CreateDateColumn()
  createdAt!: Date;
}
