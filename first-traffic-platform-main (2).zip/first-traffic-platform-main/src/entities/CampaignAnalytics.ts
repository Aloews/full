import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  CreateDateColumn,
  Index,
} from 'typeorm';
import { Campaign } from './Campaign';

@Entity('campaign_analytics')
@Index(['campaignId', 'date'])
export class CampaignAnalytics {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  @Index()
  campaignId!: string;

  @ManyToOne(() => Campaign, (campaign) => campaign.analytics, { onDelete: 'CASCADE' })
  campaign!: Campaign;

  @Column({ type: 'date' })
  @Index()
  date!: Date;

  @Column({ default: 0 })
  impressions!: number;

  @Column({ default: 0 })
  clicks!: number;

  @Column({ default: 0 })
  conversions!: number;

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  spent!: number;

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  revenue!: number;

  @CreateDateColumn()
  createdAt!: Date;
}
