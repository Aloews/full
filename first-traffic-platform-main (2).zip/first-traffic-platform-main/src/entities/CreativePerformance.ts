import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  CreateDateColumn,
  Index,
} from 'typeorm';
import { Creative } from './Creative';
import { Campaign } from './Campaign';

@Entity('creative_performance')
@Index(['creativeId', 'date'])
@Index(['campaignId', 'date'])
export class CreativePerformance {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @Column()
  @Index()
  creativeId!: string;

  @ManyToOne(() => Creative, { onDelete: 'CASCADE' })
  creative!: Creative;

  @Column()
  @Index()
  campaignId!: string;

  @ManyToOne(() => Campaign, { onDelete: 'CASCADE' })
  campaign!: Campaign;

  @Column({ type: 'date' })
  @Index()
  date!: Date;

  @Column({ default: 0 })
  impressions!: number;

  @Column({ default: 0 })
  clicks!: number;

  @Column({ default: 0 })
  conversions!: number;

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  spent!: number;

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  revenue!: number;

  // Derived metrics stored for fast reads
  @Column('decimal', { precision: 8, scale: 4, default: 0 })
  ctr!: number; // clicks / impressions * 100

  @Column('decimal', { precision: 10, scale: 4, default: 0 })
  cpc!: number; // spent / clicks

  @Column('decimal', { precision: 10, scale: 4, default: 0 })
  cpa!: number; // spent / conversions

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  roi!: number; // (revenue - spent) / spent * 100

  @CreateDateColumn()
  createdAt!: Date;
}
