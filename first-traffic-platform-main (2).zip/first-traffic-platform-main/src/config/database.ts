import 'reflect-metadata';
import { DataSource } from 'typeorm';
import { User } from '../entities/User';
import { Campaign } from '../entities/Campaign';
import { RTBAuction } from '../entities/RTBAuction';
import { CampaignAnalytics } from '../entities/CampaignAnalytics';
import { Creative } from '../entities/Creative';
import { CreativePerformance } from '../entities/CreativePerformance';
import { TrafficSource } from '../entities/TrafficSource';
import { TrafficFilter } from '../entities/TrafficFilter';
import { FrequencyCap } from '../entities/FrequencyCap';

const isProduction = process.env.NODE_ENV === 'production';

// Railway provides DATABASE_URL; fallback to individual vars for local dev
const dataSourceOptions = process.env.DATABASE_URL
  ? {
      type: 'postgres' as const,
      url: process.env.DATABASE_URL,
      ssl: { rejectUnauthorized: false },
    }
  : {
      type: 'postgres' as const,
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '5432'),
      username: process.env.DB_USER || 'postgres',
      password: process.env.DB_PASSWORD || 'postgres123',
      database: process.env.DB_NAME || 'traffic_platform',
      ssl: false as any,
    };

export const AppDataSource = new DataSource({
  ...dataSourceOptions,
  synchronize: true,   // always sync — Railway DB is fresh on each deploy
  logging: !isProduction,
  entities: [
    User,
    Campaign,
    RTBAuction,
    CampaignAnalytics,
    Creative,
    CreativePerformance,
    TrafficSource,
    TrafficFilter,
    FrequencyCap,
  ],
  migrations: [],
  migrationsRun: false,
});
