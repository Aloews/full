import Redis from 'ioredis';

const REDIS_URL = process.env.REDIS_URL || '';

// If no Redis URL provided, use a mock client that silently no-ops
class MockRedis {
  async get(_key: string): Promise<null> { return null; }
  async set(_key: string, _value: string, ..._args: any[]): Promise<'OK'> { return 'OK'; }
  async del(_key: string): Promise<number> { return 0; }
  async ping(): Promise<string> { throw new Error('Redis not configured'); }
}

export const redisClient: {
  get(key: string): Promise<string | null>;
  set(key: string, value: string, ...args: any[]): Promise<any>;
  del(key: string): Promise<number>;
  ping(): Promise<string>;
} = REDIS_URL ? new Redis(REDIS_URL) : new MockRedis() as any;

export const CACHE_TTL = 60; // seconds

export async function getCache<T>(key: string): Promise<T | null> {
  try {
    const data = await redisClient.get(key);
    return data ? (JSON.parse(data) as T) : null;
  } catch {
    return null;
  }
}

export async function setCache(key: string, value: unknown, ttl = CACHE_TTL): Promise<void> {
  try {
    await redisClient.set(key, JSON.stringify(value), 'EX', ttl);
  } catch {}
}

export async function invalidateCache(key: string): Promise<void> {
  try {
    await redisClient.del(key);
  } catch {}
}
