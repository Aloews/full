import { z } from 'zod';

export const bidRequestSchema = z.object({
  id: z.string().min(1, 'Bid request ID is required'),
  imp: z
    .array(
      z.object({
        id: z.string(),
        banner: z.record(z.any()).optional(),
        video: z.record(z.any()).optional(),
        bidfloor: z.number().optional().default(0),
      })
    )
    .min(1, 'At least one impression is required'),
  site: z.record(z.any()).optional(),
  app: z.record(z.any()).optional(),
  device: z.record(z.any()).optional(),
  user: z.record(z.any()).optional(),
});

export const winNotificationSchema = z.object({
  clearingPrice: z.number().positive().optional(),
});

export type BidRequestDto = z.infer<typeof bidRequestSchema>;
export type WinNotificationDto = z.infer<typeof winNotificationSchema>;
