import { Router } from 'express';
import { validate } from '../../middleware/validate';
import { bidRequestSchema, winNotificationSchema } from './rtb.schemas';
import { bid, winNotification } from './rtb.controller';

const router = Router();

router.post('/bid', validate(bidRequestSchema), bid);
router.post('/win/:auctionId', validate(winNotificationSchema), winNotification);

export default router;
