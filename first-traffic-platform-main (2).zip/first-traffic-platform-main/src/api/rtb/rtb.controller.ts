import { Request, Response, NextFunction } from 'express';
import { processBidRequest, processWinNotification } from './rtb.service';

export async function bid(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await processBidRequest(req.body);
    if (!result) return res.status(204).send(); // No bid
    res.json(result);
  } catch (err) {
    next(err);
  }
}

export async function winNotification(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await processWinNotification(req.params.auctionId, req.body);
    res.json(result);
  } catch (err) {
    next(err);
  }
}
