import { AppDataSource } from '../../config/database';
import { RTBAuction } from '../../entities/RTBAuction';
import { Campaign } from '../../entities/Campaign';
import { AppError } from '../../middleware/errorHandler';
import { invalidateStatsCache } from '../analytics/analytics.service';
import { filterBidRequest, calculateBidMultipliers, recordImpression } from '../../services/trafficQuality.service';
import { BidRequestDto, WinNotificationDto } from './rtb.schemas';

const auctionRepo = () => AppDataSource.getRepository(RTBAuction);
const campaignRepo = () => AppDataSource.getRepository(Campaign);

function calculateBaseBid(campaign: Campaign, bidFloor: number): number {
  const remainingBudget = Number(campaign.totalBudget) - Number(campaign.spent);
  if (remainingBudget <= 0) return 0;

  let bid = 0;
  switch (campaign.bidStrategy) {
    case 'CPM':          bid = Math.min(remainingBudget * 0.01, 5.0); break;
    case 'CPC':          bid = Math.min(remainingBudget * 0.005, 2.0); break;
    case 'CPA':          bid = Math.min(remainingBudget * 0.002, 1.0); break;
    case 'ROI_OPTIMIZED':
    default:             bid = Math.min(remainingBudget * 0.008, 3.0); break;
  }

  return bid >= bidFloor ? parseFloat(bid.toFixed(4)) : 0;
}

export async function processBidRequest(dto: BidRequestDto) {
  const bidFloor = dto.imp[0]?.bidfloor ?? 0;

  // Extract context from bid request
  const ctx = {
    domain: (dto.site as any)?.domain || (dto.app as any)?.bundle,
    ip: (dto.device as any)?.ip,
    geo: (dto.device as any)?.geo,
    device: {
      type: (dto.device as any)?.devicetype?.toString(),
      os: (dto.device as any)?.os,
      ua: (dto.device as any)?.ua,
      ifa: (dto.device as any)?.ifa,
    },
    userId: (dto.user as any)?.id,
    campaignId: '', // will be set per campaign
    ownerId: '',    // will be set per campaign
  };

  const campaigns = await campaignRepo().find({ where: { status: 'active' } });
  if (campaigns.length === 0) return null;

  let bestCampaign: Campaign | null = null;
  let bestBid = 0;
  let bestMultiplier = 1.0;
  let filterReason: string | undefined;

  for (const campaign of campaigns) {
    // Run traffic filter for this campaign's owner
    const filterCtx = { ...ctx, campaignId: campaign.id, ownerId: campaign.userId };
    const filterResult = await filterBidRequest(filterCtx);

    if (!filterResult.allowed) {
      filterReason = filterResult.reason;
      continue;
    }

    const baseBid = calculateBaseBid(campaign, bidFloor);
    if (baseBid === 0) continue;

    // Apply targeting multipliers
    const multiplier = calculateBidMultipliers(filterCtx, campaign.targeting || {});
    const finalBid = parseFloat((baseBid * multiplier * (filterResult.qualityScore / 100)).toFixed(4));

    if (finalBid > bestBid) {
      bestBid = finalBid;
      bestCampaign = campaign;
      bestMultiplier = multiplier;
    }
  }

  if (!bestCampaign || bestBid === 0) {
    return null; // No bid — filtered or no budget
  }

  const auction = auctionRepo().create({
    campaignId: bestCampaign.id,
    bidPrice: bestBid,
    bidRequest: dto,
    bidResponse: { id: dto.id, price: bestBid, campaignId: bestCampaign.id },
    won: false,
  });
  await auctionRepo().save(auction);

  // Record impression for frequency capping
  const deviceId = (dto.device as any)?.ifa || (dto.user as any)?.id;
  if (deviceId) await recordImpression(deviceId, bestCampaign.id);

  return {
    id: auction.id,
    price: bestBid,
    campaignId: bestCampaign.id,
    multiplier: bestMultiplier,
  };
}

export async function processWinNotification(auctionId: string, dto: WinNotificationDto) {
  const auction = await auctionRepo().findOne({ where: { id: auctionId } });
  if (!auction) throw new AppError('Auction not found', 404);

  const clearingPrice = dto.clearingPrice ?? auction.bidPrice;
  auction.won = true;
  auction.clearingPrice = clearingPrice;
  await auctionRepo().save(auction);

  await campaignRepo()
    .createQueryBuilder()
    .update(Campaign)
    .set({ spent: () => `spent + ${clearingPrice}` })
    .where('id = :id', { id: auction.campaignId })
    .execute();

  const campaign = await campaignRepo().findOne({ where: { id: auction.campaignId } });
  if (campaign) await invalidateStatsCache(campaign.userId);

  return { success: true, auctionId: auction.id, clearingPrice };
}

export async function getRtbStats(campaignId: string) {
  const result = await auctionRepo()
    .createQueryBuilder('a')
    .select('COUNT(*)', 'totalBids')
    .addSelect('SUM(CASE WHEN a.won = true THEN 1 ELSE 0 END)', 'wins')
    .addSelect('AVG(a.bidPrice)', 'avgBidPrice')
    .addSelect('AVG(CASE WHEN a.won = true THEN a.clearingPrice END)', 'avgClearingPrice')
    .addSelect('SUM(CASE WHEN a.won = true THEN a.clearingPrice ELSE 0 END)', 'totalSpent')
    .where('a.campaignId = :campaignId', { campaignId })
    .getRawOne();

  const totalBids = parseInt(result.totalBids) || 0;
  const wins = parseInt(result.wins) || 0;

  return {
    totalBids,
    wins,
    winRate: totalBids > 0 ? parseFloat(((wins / totalBids) * 100).toFixed(2)) : 0,
    avgBidPrice: parseFloat(parseFloat(result.avgBidPrice || 0).toFixed(4)),
    avgClearingPrice: parseFloat(parseFloat(result.avgClearingPrice || 0).toFixed(4)),
    totalSpent: parseFloat(parseFloat(result.totalSpent || 0).toFixed(2)),
  };
}
