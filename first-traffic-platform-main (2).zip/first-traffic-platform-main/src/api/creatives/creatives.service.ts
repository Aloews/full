import OpenAI from 'openai';
import { AppDataSource } from '../../config/database';
import { Creative } from '../../entities/Creative';
import { AppError } from '../../middleware/errorHandler';
import {
  GenerateFromDescriptionDto,
  GenerateFromLogoDto,
  UpdateCreativeDto,
} from './creatives.schemas';

const repo = () => AppDataSource.getRepository(Creative);

function getOpenAI(): OpenAI {
  if (!process.env.OPENAI_API_KEY) {
    throw new AppError('OpenAI API key not configured. Set OPENAI_API_KEY in environment.', 503);
  }
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

async function generateAdCopy(params: {
  brandDescription: string;
  targetAudience?: string;
  tone: string;
  type: string;
}): Promise<{ headline: string; bodyText: string; ctaText: string }> {
  const openai = getOpenAI();
  const prompt = `You are an expert ad copywriter for traffic arbitrage campaigns.
Create ad copy for:
- Brand/Product: ${params.brandDescription}
- Ad type: ${params.type}
- Tone: ${params.tone}
${params.targetAudience ? `- Target audience: ${params.targetAudience}` : ''}

Respond ONLY with valid JSON:
{"headline": "short punchy headline (max 30 chars)", "bodyText": "compelling body text (max 90 chars)", "ctaText": "CTA button text (max 15 chars)"}`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{ role: 'user', content: prompt }],
    response_format: { type: 'json_object' },
    temperature: 0.8,
  });

  const content = response.choices[0]?.message?.content;
  if (!content) throw new AppError('Failed to generate ad copy', 500);
  return JSON.parse(content);
}

async function generateAdImage(params: {
  prompt: string;
  width?: number;
  height?: number;
}): Promise<string> {
  const openai = getOpenAI();
  const size: any = params.width && params.height && params.width > params.height
    ? '1792x1024'
    : '1024x1024';

  const response = await openai.images.generate({
    model: 'dall-e-3',
    prompt: `Professional advertising banner. ${params.prompt}. Clean modern design, no text overlay, suitable for digital advertising.`,
    n: 1,
    size,
    quality: 'standard',
  });
  const imageUrl = response.data[0]?.url;
  if (!imageUrl) throw new AppError('Failed to generate image', 500);
  return imageUrl;
}

async function analyzeLogo(logoUrl: string, brandName: string): Promise<{
  brandColors: string[];
  brandStyle: string;
  suggestedPrompt: string;
}> {
  const openai = getOpenAI();
  const response = await openai.chat.completions.create({
    model: 'gpt-4o',
    messages: [{
      role: 'user',
      content: [
        { type: 'image_url', image_url: { url: logoUrl } },
        {
          type: 'text',
          text: `Analyze this logo for brand "${brandName}" and respond ONLY with valid JSON:
{"brandColors": ["#hex1"], "brandStyle": "modern", "suggestedPrompt": "detailed image generation prompt"}`,
        },
      ],
    }],
    response_format: { type: 'json_object' },
  });
  const content = response.choices[0]?.message?.content;
  if (!content) throw new AppError('Failed to analyze logo', 500);
  return JSON.parse(content);
}

export async function getCreatives(userId: string) {
  return repo().find({ where: { userId }, order: { createdAt: 'DESC' } });
}

export async function getCreativeById(id: string, userId: string): Promise<Creative> {
  const creative = await repo().findOne({ where: { id, userId } });
  if (!creative) throw new AppError('Creative not found', 404);
  return creative;
}

export async function generateFromDescription(
  dto: GenerateFromDescriptionDto,
  userId: string
): Promise<Creative> {
  const creative = repo().create({
    name: dto.name,
    type: dto.type,
    status: 'generating',
    generationSource: 'description',
    brandDescription: dto.brandDescription,
    prompt: dto.brandDescription,
    landingUrl: dto.landingUrl,
    width: dto.width,
    height: dto.height,
    userId,
  });
  await repo().save(creative);

  setImmediate(async () => {
    try {
      const [copy, imageUrl] = await Promise.all([
        generateAdCopy({
          brandDescription: dto.brandDescription,
          targetAudience: dto.targetAudience,
          tone: dto.tone,
          type: dto.type,
        }),
        generateAdImage({
          prompt: `${dto.brandDescription}. Style: ${dto.tone} advertising creative for ${dto.type} ad.`,
          width: dto.width,
          height: dto.height,
        }),
      ]);
      await repo().update(creative.id, {
        status: 'ready',
        headline: copy.headline,
        bodyText: copy.bodyText,
        ctaText: copy.ctaText,
        imageUrl,
        aiMetadata: { tone: dto.tone, targetAudience: dto.targetAudience, generatedAt: new Date().toISOString() } as any,
      });
    } catch (err: any) {
      await repo().update(creative.id, { status: 'failed', errorMessage: err.message });
    }
  });

  return creative;
}

export async function generateFromLogo(
  dto: GenerateFromLogoDto,
  userId: string
): Promise<Creative> {
  const creative = repo().create({
    name: dto.name,
    type: dto.type,
    status: 'generating',
    generationSource: 'logo',
    logoUrl: dto.logoUrl,
    prompt: `Brand: ${dto.brandName}${dto.tagline ? `, tagline: ${dto.tagline}` : ''}`,
    landingUrl: dto.landingUrl,
    width: dto.width,
    height: dto.height,
    userId,
  });
  await repo().save(creative);

  setImmediate(async () => {
    try {
      const brandInfo = await analyzeLogo(dto.logoUrl, dto.brandName);
      const [copy, imageUrl] = await Promise.all([
        generateAdCopy({
          brandDescription: `Brand: ${dto.brandName}. Style: ${brandInfo.brandStyle}${dto.tagline ? `. Tagline: ${dto.tagline}` : ''}`,
          tone: 'professional',
          type: dto.type,
        }),
        generateAdImage({ prompt: brandInfo.suggestedPrompt, width: dto.width, height: dto.height }),
      ]);
      await repo().update(creative.id, {
        status: 'ready',
        headline: copy.headline,
        bodyText: copy.bodyText,
        ctaText: copy.ctaText,
        imageUrl,
        aiMetadata: { brandColors: brandInfo.brandColors, brandStyle: brandInfo.brandStyle, generatedAt: new Date().toISOString() } as any,
      });
    } catch (err: any) {
      await repo().update(creative.id, { status: 'failed', errorMessage: err.message });
    }
  });

  return creative;
}

export async function updateCreative(
  id: string,
  userId: string,
  dto: UpdateCreativeDto
): Promise<Creative> {
  const creative = await getCreativeById(id, userId);
  Object.assign(creative, dto);
  return repo().save(creative);
}

export async function deleteCreative(id: string, userId: string): Promise<void> {
  const creative = await getCreativeById(id, userId);
  await repo().remove(creative);
}

export async function regenerateCreative(id: string, userId: string): Promise<Creative> {
  const creative = await getCreativeById(id, userId);
  await repo().update(id, { status: 'generating', errorMessage: undefined as any });

  setImmediate(async () => {
    try {
      const desc = creative.prompt || creative.brandDescription || creative.name;
      if (creative.generationSource === 'logo' && creative.logoUrl) {
        const brandInfo = await analyzeLogo(creative.logoUrl, creative.name);
        const [copy, imageUrl] = await Promise.all([
          generateAdCopy({ brandDescription: brandInfo.suggestedPrompt, tone: 'professional', type: creative.type }),
          generateAdImage({ prompt: brandInfo.suggestedPrompt }),
        ]);
        await repo().update(id, {
          status: 'ready',
          headline: copy.headline,
          bodyText: copy.bodyText,
          ctaText: copy.ctaText,
          imageUrl,
          aiMetadata: { brandColors: brandInfo.brandColors, regeneratedAt: new Date().toISOString() } as any,
        });
      } else {
        const [copy, imageUrl] = await Promise.all([
          generateAdCopy({ brandDescription: desc, tone: 'professional', type: creative.type }),
          generateAdImage({ prompt: desc }),
        ]);
        await repo().update(id, {
          status: 'ready',
          headline: copy.headline,
          bodyText: copy.bodyText,
          ctaText: copy.ctaText,
          imageUrl,
          aiMetadata: { regeneratedAt: new Date().toISOString() } as any,
        });
      }
    } catch (err: any) {
      await repo().update(id, { status: 'failed', errorMessage: err.message });
    }
  });

  return { ...creative, status: 'generating' };
}
