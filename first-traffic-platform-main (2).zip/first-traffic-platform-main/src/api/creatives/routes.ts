import { Router } from 'express';
import { authMiddleware } from '../../middleware/auth';
import { validate } from '../../middleware/validate';
import { apiLimiter } from '../../middleware/rateLimiter';
import {
  generateFromDescriptionSchema,
  generateFromLogoSchema,
  updateCreativeSchema,
} from './creatives.schemas';
import {
  list,
  getOne,
  createFromDescription,
  createFromLogo,
  update,
  remove,
  regenerate,
} from './creatives.controller';

const router = Router();
router.use(authMiddleware, apiLimiter);

router.get('/', list);
router.get('/:id', getOne);
router.post('/generate/description', validate(generateFromDescriptionSchema), createFromDescription);
router.post('/generate/logo', validate(generateFromLogoSchema), createFromLogo);
router.patch('/:id', validate(updateCreativeSchema), update);
router.post('/:id/regenerate', regenerate);
router.delete('/:id', remove);

export default router;
