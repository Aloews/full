import { Response, NextFunction } from 'express';
import { AuthRequest } from '../../middleware/auth';
import {
  getCreatives,
  getCreativeById,
  generateFromDescription,
  generateFromLogo,
  updateCreative,
  deleteCreative,
  regenerateCreative,
} from './creatives.service';

export async function list(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const creatives = await getCreatives(req.user!.id);
    res.json(creatives);
  } catch (err) { next(err); }
}

export async function getOne(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const creative = await getCreativeById(req.params.id, req.user!.id);
    res.json(creative);
  } catch (err) { next(err); }
}

export async function createFromDescription(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const creative = await generateFromDescription(req.body, req.user!.id);
    res.status(202).json({
      ...creative,
      message: 'Creative generation started. Poll GET /api/creatives/:id for status.',
    });
  } catch (err) { next(err); }
}

export async function createFromLogo(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const creative = await generateFromLogo(req.body, req.user!.id);
    res.status(202).json({
      ...creative,
      message: 'Creative generation started. Poll GET /api/creatives/:id for status.',
    });
  } catch (err) { next(err); }
}

export async function update(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const creative = await updateCreative(req.params.id, req.user!.id, req.body);
    res.json(creative);
  } catch (err) { next(err); }
}

export async function remove(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    await deleteCreative(req.params.id, req.user!.id);
    res.status(204).send();
  } catch (err) { next(err); }
}

export async function regenerate(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const creative = await regenerateCreative(req.params.id, req.user!.id);
    res.status(202).json({
      ...creative,
      message: 'Regeneration started. Poll GET /api/creatives/:id for status.',
    });
  } catch (err) { next(err); }
}
