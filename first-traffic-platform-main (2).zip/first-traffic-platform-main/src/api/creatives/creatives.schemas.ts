import { z } from 'zod';

export const generateFromDescriptionSchema = z.object({
  name: z.string().min(1, 'Creative name is required'),
  type: z.enum(['banner', 'native', 'push']).default('banner'),
  brandDescription: z.string().min(10, 'Brand description must be at least 10 characters'),
  targetAudience: z.string().optional(),
  tone: z.enum(['professional', 'casual', 'urgent', 'friendly']).default('professional'),
  landingUrl: z.string().url('Must be a valid URL').optional(),
  width: z.number().int().positive().optional(),
  height: z.number().int().positive().optional(),
});

export const generateFromLogoSchema = z.object({
  name: z.string().min(1, 'Creative name is required'),
  type: z.enum(['banner', 'native', 'push']).default('banner'),
  logoUrl: z.string().url('Must be a valid logo URL'),
  brandName: z.string().min(1, 'Brand name is required'),
  tagline: z.string().optional(),
  landingUrl: z.string().url('Must be a valid URL').optional(),
  width: z.number().int().positive().optional(),
  height: z.number().int().positive().optional(),
});

export const updateCreativeSchema = z.object({
  name: z.string().min(1).optional(),
  headline: z.string().optional(),
  bodyText: z.string().optional(),
  ctaText: z.string().optional(),
  landingUrl: z.string().url().optional(),
  status: z.enum(['pending', 'generating', 'ready', 'failed']).optional(),
});

export type GenerateFromDescriptionDto = z.infer<typeof generateFromDescriptionSchema>;
export type GenerateFromLogoDto = z.infer<typeof generateFromLogoSchema>;
export type UpdateCreativeDto = z.infer<typeof updateCreativeSchema>;
