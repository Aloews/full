import { AppDataSource } from '../../config/database';
import { TrafficSource } from '../../entities/TrafficSource';
import { TrafficFilter } from '../../entities/TrafficFilter';
import { AppError } from '../../middleware/errorHandler';
import { invalidateCache } from '../../config/redis';
import { CreateSourceDto, UpdateSourceDto, CreateFilterDto, UpdateFilterDto } from './traffic.schemas';

const sourceRepo = () => AppDataSource.getRepository(TrafficSource);
const filterRepo = () => AppDataSource.getRepository(TrafficFilter);

// ── Traffic Sources ──
export async function getSources(userId: string) {
  return sourceRepo().find({ where: { userId }, order: { qualityScore: 'DESC' } });
}

export async function getSourceById(id: string, userId: string) {
  const source = await sourceRepo().findOne({ where: { id, userId } });
  if (!source) throw new AppError('Traffic source not found', 404);
  return source;
}

export async function createSource(dto: CreateSourceDto, userId: string) {
  const source = sourceRepo().create({ ...dto, userId });
  return sourceRepo().save(source);
}

export async function updateSource(id: string, userId: string, dto: UpdateSourceDto) {
  const source = await getSourceById(id, userId);
  Object.assign(source, dto);
  return sourceRepo().save(source);
}

export async function deleteSource(id: string, userId: string) {
  const source = await getSourceById(id, userId);
  await sourceRepo().remove(source);
}

// ── Traffic Filters ──
export async function getFilters(userId: string) {
  return filterRepo().find({ where: { userId }, order: { createdAt: 'DESC' } });
}

export async function getFilterById(id: string, userId: string) {
  const filter = await filterRepo().findOne({ where: { id, userId } });
  if (!filter) throw new AppError('Traffic filter not found', 404);
  return filter;
}

export async function createFilter(dto: CreateFilterDto, userId: string) {
  const filter = filterRepo().create({ ...dto, userId });
  const saved = await filterRepo().save(filter);
  await invalidateCache(`filters:${userId}`);
  return saved;
}

export async function updateFilter(id: string, userId: string, dto: UpdateFilterDto) {
  const filter = await getFilterById(id, userId);
  Object.assign(filter, dto);
  const saved = await filterRepo().save(filter);
  await invalidateCache(`filters:${userId}`);
  return saved;
}

export async function deleteFilter(id: string, userId: string) {
  const filter = await getFilterById(id, userId);
  await filterRepo().remove(filter);
  await invalidateCache(`filters:${userId}`);
}

// ── Quality overview ──
export async function getQualityOverview(userId: string) {
  const sources = await getSources(userId);
  const filters = await getFilters(userId);

  const avgQuality = sources.length
    ? sources.reduce((s, src) => s + Number(src.qualityScore), 0) / sources.length
    : 0;

  return {
    totalSources: sources.length,
    activeSources: sources.filter((s) => s.status === 'active').length,
    blockedSources: sources.filter((s) => s.status === 'blocked').length,
    avgQualityScore: parseFloat(avgQuality.toFixed(2)),
    totalFilters: filters.length,
    activeFilters: filters.filter((f) => f.active).length,
    topSources: sources.slice(0, 5).map((s) => ({
      id: s.id, name: s.name, qualityScore: s.qualityScore,
      bidMultiplier: s.bidMultiplier, status: s.status,
    })),
    worstSources: [...sources].sort((a, b) => Number(a.qualityScore) - Number(b.qualityScore))
      .slice(0, 3).map((s) => ({
        id: s.id, name: s.name, qualityScore: s.qualityScore, botRate: s.botRate, status: s.status,
      })),
  };
}
