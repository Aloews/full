import { Response, NextFunction } from 'express';
import { AuthRequest } from '../../middleware/auth';
import {
  getSources, getSourceById, createSource, updateSource, deleteSource,
  getFilters, getFilterById, createFilter, updateFilter, deleteFilter,
  getQualityOverview,
} from './traffic.service';

// Sources
export async function listSources(req: AuthRequest, res: Response, next: NextFunction) {
  try { res.json(await getSources(req.user!.id)); } catch (e) { next(e); }
}
export async function getSource(req: AuthRequest, res: Response, next: NextFunction) {
  try { res.json(await getSourceById(req.params.id, req.user!.id)); } catch (e) { next(e); }
}
export async function addSource(req: AuthRequest, res: Response, next: NextFunction) {
  try { res.status(201).json(await createSource(req.body, req.user!.id)); } catch (e) { next(e); }
}
export async function editSource(req: AuthRequest, res: Response, next: NextFunction) {
  try { res.json(await updateSource(req.params.id, req.user!.id, req.body)); } catch (e) { next(e); }
}
export async function removeSource(req: AuthRequest, res: Response, next: NextFunction) {
  try { await deleteSource(req.params.id, req.user!.id); res.status(204).send(); } catch (e) { next(e); }
}

// Filters
export async function listFilters(req: AuthRequest, res: Response, next: NextFunction) {
  try { res.json(await getFilters(req.user!.id)); } catch (e) { next(e); }
}
export async function getFilter(req: AuthRequest, res: Response, next: NextFunction) {
  try { res.json(await getFilterById(req.params.id, req.user!.id)); } catch (e) { next(e); }
}
export async function addFilter(req: AuthRequest, res: Response, next: NextFunction) {
  try { res.status(201).json(await createFilter(req.body, req.user!.id)); } catch (e) { next(e); }
}
export async function editFilter(req: AuthRequest, res: Response, next: NextFunction) {
  try { res.json(await updateFilter(req.params.id, req.user!.id, req.body)); } catch (e) { next(e); }
}
export async function removeFilter(req: AuthRequest, res: Response, next: NextFunction) {
  try { await deleteFilter(req.params.id, req.user!.id); res.status(204).send(); } catch (e) { next(e); }
}

// Overview
export async function qualityOverview(req: AuthRequest, res: Response, next: NextFunction) {
  try { res.json(await getQualityOverview(req.user!.id)); } catch (e) { next(e); }
}
