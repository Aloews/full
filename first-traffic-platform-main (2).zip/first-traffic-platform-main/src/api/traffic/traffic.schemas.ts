import { z } from 'zod';

export const createSourceSchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  endpoint: z.string().url('Must be a valid SSP endpoint URL'),
  bidMultiplier: z.number().min(0.1).max(5.0).default(1.0),
  metadata: z.record(z.any()).default({}),
});

export const updateSourceSchema = createSourceSchema.partial().extend({
  status: z.enum(['active', 'paused', 'blocked']).optional(),
});

export const createFilterSchema = z.object({
  name: z.string().min(1),
  type: z.enum([
    'block_domain', 'block_ip', 'block_geo', 'block_device',
    'block_os', 'min_quality_score', 'max_bot_rate', 'frequency_cap',
  ]),
  value: z.any(),
  description: z.string().optional(),
  active: z.boolean().default(true),
});

export const updateFilterSchema = createFilterSchema.partial();

export type CreateSourceDto = z.infer<typeof createSourceSchema>;
export type UpdateSourceDto = z.infer<typeof updateSourceSchema>;
export type CreateFilterDto = z.infer<typeof createFilterSchema>;
export type UpdateFilterDto = z.infer<typeof updateFilterSchema>;
