import { Router } from 'express';
import { authMiddleware } from '../../middleware/auth';
import { validate } from '../../middleware/validate';
import { apiLimiter } from '../../middleware/rateLimiter';
import { createSourceSchema, updateSourceSchema, createFilterSchema, updateFilterSchema } from './traffic.schemas';
import {
  listSources, getSource, addSource, editSource, removeSource,
  listFilters, getFilter, addFilter, editFilter, removeFilter,
  qualityOverview,
} from './traffic.controller';

const router = Router();
router.use(authMiddleware, apiLimiter);

// Quality overview
router.get('/overview', qualityOverview);

// Traffic sources
router.get('/sources', listSources);
router.post('/sources', validate(createSourceSchema), addSource);
router.get('/sources/:id', getSource);
router.patch('/sources/:id', validate(updateSourceSchema), editSource);
router.delete('/sources/:id', removeSource);

// Traffic filters
router.get('/filters', listFilters);
router.post('/filters', validate(createFilterSchema), addFilter);
router.get('/filters/:id', getFilter);
router.patch('/filters/:id', validate(updateFilterSchema), editFilter);
router.delete('/filters/:id', removeFilter);

export default router;
