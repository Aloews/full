import { Response, NextFunction } from 'express';
import { AuthRequest } from '../../middleware/auth';
import {
  getDashboardStats,
  getCampaignPerformance,
  getTopCampaigns,
  getCreativePerformance,
  getAiInsights,
  compareCampaigns,
} from './analytics.service';
import { analyticsRangeSchema, creativeAnalyticsSchema, aiInsightSchema } from './analytics.schemas';
import { AppError } from '../../middleware/errorHandler';
import { getRtbStats } from '../rtb/rtb.service';

export async function stats(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const result = await getDashboardStats(req.user!.id);
    res.json(result);
  } catch (err) { next(err); }
}

export async function performance(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const parsed = analyticsRangeSchema.safeParse(req.query);
    if (!parsed.success) throw new AppError(parsed.error.errors.map((e) => e.message).join(', '), 400);
    const result = await getCampaignPerformance(req.user!.id, parsed.data);
    res.json(result);
  } catch (err) { next(err); }
}

export async function topCampaigns(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const limit = Math.min(parseInt(req.query.limit as string) || 5, 20);
    const result = await getTopCampaigns(req.user!.id, limit);
    res.json(result);
  } catch (err) { next(err); }
}

export async function creativePerformance(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const parsed = creativeAnalyticsSchema.safeParse(req.query);
    if (!parsed.success) throw new AppError(parsed.error.errors.map((e) => e.message).join(', '), 400);
    const result = await getCreativePerformance(req.user!.id, parsed.data);
    res.json(result);
  } catch (err) { next(err); }
}

export async function aiInsights(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const parsed = aiInsightSchema.safeParse(req.query);
    if (!parsed.success) throw new AppError(parsed.error.errors.map((e) => e.message).join(', '), 400);
    const result = await getAiInsights(req.user!.id, parsed.data);
    res.json(result);
  } catch (err) { next(err); }
}

export async function compare(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { campaignIds, startDate, endDate } = req.body;
    if (!Array.isArray(campaignIds) || campaignIds.length < 2) {
      throw new AppError('Provide at least 2 campaignIds to compare', 400);
    }
    if (!startDate || !endDate) throw new AppError('startDate and endDate are required', 400);
    const result = await compareCampaigns(req.user!.id, campaignIds, startDate, endDate);
    res.json(result);
  } catch (err) { next(err); }
}

export async function rtbStats(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { campaignId } = req.params;
    const result = await getRtbStats(campaignId);
    res.json(result);
  } catch (err) { next(err); }
}

// Legacy range endpoint kept for backwards compatibility
export async function range(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const parsed = analyticsRangeSchema.safeParse(req.query);
    if (!parsed.success) throw new AppError(parsed.error.errors.map((e) => e.message).join(', '), 400);
    const result = await getCampaignPerformance(req.user!.id, parsed.data);
    res.json(result);
  } catch (err) { next(err); }
}
