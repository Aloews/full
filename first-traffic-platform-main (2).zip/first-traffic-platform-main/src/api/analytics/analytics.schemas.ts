import { z } from 'zod';

export const analyticsRangeSchema = z.object({
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'startDate must be YYYY-MM-DD'),
  endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'endDate must be YYYY-MM-DD'),
  campaignId: z.string().uuid().optional(),
  groupBy: z.enum(['day', 'week', 'month']).default('day'),
});

export const creativeAnalyticsSchema = z.object({
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'startDate must be YYYY-MM-DD'),
  endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'endDate must be YYYY-MM-DD'),
  creativeId: z.string().uuid().optional(),
  campaignId: z.string().uuid().optional(),
  sortBy: z.enum(['ctr', 'cpc', 'cpa', 'roi', 'impressions', 'conversions']).default('roi'),
});

export const aiInsightSchema = z.object({
  campaignId: z.string().uuid().optional(),
  creativeId: z.string().uuid().optional(),
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
});

export type AnalyticsRangeDto = z.infer<typeof analyticsRangeSchema>;
export type CreativeAnalyticsDto = z.infer<typeof creativeAnalyticsSchema>;
export type AiInsightDto = z.infer<typeof aiInsightSchema>;
