import OpenAI from 'openai';
import { In } from 'typeorm';
import { AppDataSource } from '../../config/database';
import { Campaign } from '../../entities/Campaign';
import { CampaignAnalytics } from '../../entities/CampaignAnalytics';
import { CreativePerformance } from '../../entities/CreativePerformance';
import { Creative } from '../../entities/Creative';
import { getCache, setCache, invalidateCache } from '../../config/redis';
import { AnalyticsRangeDto, CreativeAnalyticsDto, AiInsightDto } from './analytics.schemas';

const campaignRepo = () => AppDataSource.getRepository(Campaign);
const analyticsRepo = () => AppDataSource.getRepository(CampaignAnalytics);
const creativeRepo = () => AppDataSource.getRepository(Creative);
const creativePerformanceRepo = () => AppDataSource.getRepository(CreativePerformance);

// ── Dashboard Stats ──
export async function getDashboardStats(userId: string) {
  const cacheKey = `stats:${userId}`;
  const cached = await getCache<object>(cacheKey);
  if (cached) return cached;

  const campaigns = await campaignRepo().find({ where: { userId } });
  const totalSpent = campaigns.reduce((sum, c) => sum + Number(c.spent), 0);
  const totalBudget = campaigns.reduce((sum, c) => sum + Number(c.totalBudget), 0);
  const activeCampaigns = campaigns.filter((c) => c.status === 'active').length;

  const since = new Date();
  since.setDate(since.getDate() - 30);

  const campaignIds = campaigns.map((c) => c.id);
  let totals = { impressions: 0, clicks: 0, conversions: 0, revenue: 0 };

  if (campaignIds.length > 0) {
    const raw = await analyticsRepo()
      .createQueryBuilder('a')
      .select('SUM(a.impressions)', 'impressions')
      .addSelect('SUM(a.clicks)', 'clicks')
      .addSelect('SUM(a.conversions)', 'conversions')
      .addSelect('SUM(a.revenue)', 'revenue')
      .where('a.campaignId IN (:...ids)', { ids: campaignIds })
      .andWhere('a.date >= :since', { since })
      .getRawOne();

    totals = {
      impressions: parseInt(raw?.impressions) || 0,
      clicks: parseInt(raw?.clicks) || 0,
      conversions: parseInt(raw?.conversions) || 0,
      revenue: parseFloat(raw?.revenue) || 0,
    };
  }

  const result = {
    totalCampaigns: campaigns.length,
    activeCampaigns,
    totalSpent: parseFloat(totalSpent.toFixed(2)),
    totalBudget: parseFloat(totalBudget.toFixed(2)),
    budgetUtilization: totalBudget > 0 ? parseFloat(((totalSpent / totalBudget) * 100).toFixed(2)) : 0,
    last30Days: {
      impressions: totals.impressions,
      clicks: totals.clicks,
      conversions: totals.conversions,
      revenue: parseFloat(totals.revenue.toFixed(2)),
      ctr: totals.impressions > 0 ? parseFloat(((totals.clicks / totals.impressions) * 100).toFixed(4)) : 0,
      cpa: totals.conversions > 0 ? parseFloat((totalSpent / totals.conversions).toFixed(2)) : 0,
      roi: totalSpent > 0 ? parseFloat((((totals.revenue - totalSpent) / totalSpent) * 100).toFixed(2)) : 0,
    },
  };

  await setCache(cacheKey, result, 60);
  return result;
}

export async function invalidateStatsCache(userId: string): Promise<void> {
  await invalidateCache(`stats:${userId}`);
}

// ── Campaign Performance Over Time ──
export async function getCampaignPerformance(userId: string, dto: AnalyticsRangeDto) {
  const cacheKey = `perf:${userId}:${dto.startDate}:${dto.endDate}:${dto.campaignId || 'all'}:${dto.groupBy}`;
  const cached = await getCache<object[]>(cacheKey);
  if (cached) return cached;

  const userCampaigns = await campaignRepo().find({ where: { userId } });
  const userCampaignIds = userCampaigns.map((c) => c.id);
  if (userCampaignIds.length === 0) return [];

  const groupExpr: Record<string, string> = {
    day: `DATE_TRUNC('day', a.date)`,
    week: `DATE_TRUNC('week', a.date)`,
    month: `DATE_TRUNC('month', a.date)`,
  };
  const expr = groupExpr[dto.groupBy] || groupExpr.day;

  let query = analyticsRepo()
    .createQueryBuilder('a')
    .select(expr, 'period')
    .addSelect('SUM(a.impressions)', 'impressions')
    .addSelect('SUM(a.clicks)', 'clicks')
    .addSelect('SUM(a.conversions)', 'conversions')
    .addSelect('SUM(a.spent)', 'spent')
    .addSelect('SUM(a.revenue)', 'revenue')
    .where('a.date BETWEEN :start AND :end', { start: dto.startDate, end: dto.endDate })
    .andWhere('a.campaignId IN (:...ids)', { ids: userCampaignIds })
    .groupBy(expr)
    .orderBy(expr, 'ASC');

  if (dto.campaignId) {
    query = query.andWhere('a.campaignId = :campaignId', { campaignId: dto.campaignId });
  }

  const rows = await query.getRawMany();

  const result = rows.map((r) => {
    const spent = parseFloat(r.spent) || 0;
    const revenue = parseFloat(r.revenue) || 0;
    const impressions = parseInt(r.impressions) || 0;
    const clicks = parseInt(r.clicks) || 0;
    const conversions = parseInt(r.conversions) || 0;
    return {
      period: r.period,
      impressions, clicks, conversions,
      spent: parseFloat(spent.toFixed(2)),
      revenue: parseFloat(revenue.toFixed(2)),
      ctr: impressions > 0 ? parseFloat(((clicks / impressions) * 100).toFixed(4)) : 0,
      cpc: clicks > 0 ? parseFloat((spent / clicks).toFixed(4)) : 0,
      cpa: conversions > 0 ? parseFloat((spent / conversions).toFixed(2)) : 0,
      roi: spent > 0 ? parseFloat((((revenue - spent) / spent) * 100).toFixed(2)) : 0,
    };
  });

  await setCache(cacheKey, result, 120);
  return result;
}

// ── Top Performing Campaigns ──
export async function getTopCampaigns(userId: string, limit = 5) {
  const cacheKey = `top-campaigns:${userId}:${limit}`;
  const cached = await getCache<object[]>(cacheKey);
  if (cached) return cached;

  const since = new Date();
  since.setDate(since.getDate() - 30);

  const userCampaigns = await campaignRepo().find({ where: { userId } });
  const ids = userCampaigns.map((c) => c.id);
  if (ids.length === 0) return [];

  const rows = await analyticsRepo()
    .createQueryBuilder('a')
    .select('a.campaignId', 'campaignId')
    .addSelect('SUM(a.impressions)', 'impressions')
    .addSelect('SUM(a.clicks)', 'clicks')
    .addSelect('SUM(a.conversions)', 'conversions')
    .addSelect('SUM(a.spent)', 'spent')
    .addSelect('SUM(a.revenue)', 'revenue')
    .where('a.campaignId IN (:...ids)', { ids })
    .andWhere('a.date >= :since', { since })
    .groupBy('a.campaignId')
    .orderBy('SUM(a.revenue) - SUM(a.spent)', 'DESC')
    .limit(limit)
    .getRawMany();

  const campaignMap = Object.fromEntries(userCampaigns.map((c) => [c.id, c]));

  const result = rows.map((r) => {
    const spent = parseFloat(r.spent) || 0;
    const revenue = parseFloat(r.revenue) || 0;
    const impressions = parseInt(r.impressions) || 0;
    const clicks = parseInt(r.clicks) || 0;
    const conversions = parseInt(r.conversions) || 0;
    const campaign = campaignMap[r.campaignId];
    return {
      campaignId: r.campaignId,
      campaignName: campaign?.name || 'Unknown',
      status: campaign?.status,
      impressions, clicks, conversions,
      spent: parseFloat(spent.toFixed(2)),
      revenue: parseFloat(revenue.toFixed(2)),
      profit: parseFloat((revenue - spent).toFixed(2)),
      roi: spent > 0 ? parseFloat((((revenue - spent) / spent) * 100).toFixed(2)) : 0,
      ctr: impressions > 0 ? parseFloat(((clicks / impressions) * 100).toFixed(4)) : 0,
    };
  });

  await setCache(cacheKey, result, 120);
  return result;
}

// ── Creative Performance ──
export async function getCreativePerformance(userId: string, dto: CreativeAnalyticsDto) {
  const cacheKey = `creative-perf:${userId}:${JSON.stringify(dto)}`;
  const cached = await getCache<object[]>(cacheKey);
  if (cached) return cached;

  const userCampaigns = await campaignRepo().find({ where: { userId } });
  const campaignIds = userCampaigns.map((c) => c.id);
  if (campaignIds.length === 0) return [];

  let query = creativePerformanceRepo()
    .createQueryBuilder('cp')
    .select('cp.creativeId', 'creativeId')
    .addSelect('SUM(cp.impressions)', 'impressions')
    .addSelect('SUM(cp.clicks)', 'clicks')
    .addSelect('SUM(cp.conversions)', 'conversions')
    .addSelect('SUM(cp.spent)', 'spent')
    .addSelect('SUM(cp.revenue)', 'revenue')
    .where('cp.date BETWEEN :start AND :end', { start: dto.startDate, end: dto.endDate })
    .andWhere('cp.campaignId IN (:...ids)', { ids: campaignIds })
    .groupBy('cp.creativeId');

  if (dto.creativeId) query = query.andWhere('cp.creativeId = :creativeId', { creativeId: dto.creativeId });
  if (dto.campaignId) query = query.andWhere('cp.campaignId = :campaignId', { campaignId: dto.campaignId });

  const sortMap: Record<string, string> = {
    ctr: 'SUM(cp.clicks) / NULLIF(SUM(cp.impressions), 0)',
    cpc: 'SUM(cp.spent) / NULLIF(SUM(cp.clicks), 0)',
    cpa: 'SUM(cp.spent) / NULLIF(SUM(cp.conversions), 0)',
    roi: '(SUM(cp.revenue) - SUM(cp.spent)) / NULLIF(SUM(cp.spent), 0)',
    impressions: 'SUM(cp.impressions)',
    conversions: 'SUM(cp.conversions)',
  };
  query = query.orderBy(sortMap[dto.sortBy] || sortMap.roi, 'DESC');

  const rows = await query.getRawMany();

  // Fix: use findBy + In() instead of deprecated findByIds
  const creativeIds = rows.map((r) => r.creativeId).filter(Boolean);
  const creatives = creativeIds.length > 0
    ? await creativeRepo().findBy({ id: In(creativeIds) })
    : [];
  const creativeMap = Object.fromEntries(creatives.map((c) => [c.id, c]));

  const result = rows.map((r) => {
    const spent = parseFloat(r.spent) || 0;
    const revenue = parseFloat(r.revenue) || 0;
    const impressions = parseInt(r.impressions) || 0;
    const clicks = parseInt(r.clicks) || 0;
    const conversions = parseInt(r.conversions) || 0;
    const creative = creativeMap[r.creativeId];
    return {
      creativeId: r.creativeId,
      creativeName: creative?.name || 'Unknown',
      creativeType: creative?.type,
      headline: creative?.headline,
      imageUrl: creative?.imageUrl,
      impressions, clicks, conversions,
      spent: parseFloat(spent.toFixed(2)),
      revenue: parseFloat(revenue.toFixed(2)),
      profit: parseFloat((revenue - spent).toFixed(2)),
      ctr: impressions > 0 ? parseFloat(((clicks / impressions) * 100).toFixed(4)) : 0,
      cpc: clicks > 0 ? parseFloat((spent / clicks).toFixed(4)) : 0,
      cpa: conversions > 0 ? parseFloat((spent / conversions).toFixed(2)) : 0,
      roi: spent > 0 ? parseFloat((((revenue - spent) / spent) * 100).toFixed(2)) : 0,
    };
  });

  await setCache(cacheKey, result, 120);
  return result;
}

// ── AI Insights ──
export async function getAiInsights(userId: string, dto: AiInsightDto) {
  if (!process.env.OPENAI_API_KEY) {
    return { error: 'OpenAI API key not configured', insights: [], recommendations: [], score: 0, summary: 'OpenAI not configured' };
  }

  const startDate = dto.startDate || new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0];
  const endDate = dto.endDate || new Date().toISOString().split('T')[0];

  const [campaignPerf, creativePerf, topCampaigns] = await Promise.all([
    getCampaignPerformance(userId, { startDate, endDate, groupBy: 'day', campaignId: dto.campaignId }),
    getCreativePerformance(userId, { startDate, endDate, sortBy: 'roi', creativeId: dto.creativeId, campaignId: dto.campaignId }),
    getTopCampaigns(userId, 5),
  ]);

  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

  const prompt = `You are an expert digital advertising analyst specializing in RTB traffic arbitrage.

Analyze the following performance data and provide actionable insights:

## Campaign Performance (${startDate} to ${endDate})
${JSON.stringify(campaignPerf.slice(-14), null, 2)}

## Top Campaigns
${JSON.stringify(topCampaigns, null, 2)}

## Creative Performance
${JSON.stringify(creativePerf.slice(0, 10), null, 2)}

Respond ONLY with valid JSON:
{
  "summary": "2-3 sentence executive summary",
  "score": 75,
  "insights": [{"type": "opportunity", "title": "...", "description": "...", "impact": "high", "metric": "roi"}],
  "recommendations": [{"priority": 1, "action": "...", "expectedImpact": "..."}],
  "bestCreative": "name or id",
  "worstCreative": "name or id"
}`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4o',
    messages: [{ role: 'user', content: prompt }],
    response_format: { type: 'json_object' },
    temperature: 0.3,
  });

  const content = response.choices[0]?.message?.content;
  if (!content) throw new Error('Failed to generate insights');

  return {
    ...JSON.parse(content),
    generatedAt: new Date().toISOString(),
    period: { startDate, endDate },
  };
}

// ── Compare Campaigns ──
export async function compareCampaigns(userId: string, campaignIds: string[], startDate: string, endDate: string) {
  const userCampaigns = await campaignRepo().find({ where: { userId } });
  const ownedIds = new Set(userCampaigns.map((c) => c.id));
  const validIds = campaignIds.filter((id) => ownedIds.has(id));
  if (validIds.length === 0) return [];

  const rows = await analyticsRepo()
    .createQueryBuilder('a')
    .select('a.campaignId', 'campaignId')
    .addSelect('SUM(a.impressions)', 'impressions')
    .addSelect('SUM(a.clicks)', 'clicks')
    .addSelect('SUM(a.conversions)', 'conversions')
    .addSelect('SUM(a.spent)', 'spent')
    .addSelect('SUM(a.revenue)', 'revenue')
    .where('a.campaignId IN (:...ids)', { ids: validIds })
    .andWhere('a.date BETWEEN :start AND :end', { start: startDate, end: endDate })
    .groupBy('a.campaignId')
    .getRawMany();

  const campaignMap = Object.fromEntries(userCampaigns.map((c) => [c.id, c]));

  return rows.map((r) => {
    const spent = parseFloat(r.spent) || 0;
    const revenue = parseFloat(r.revenue) || 0;
    const impressions = parseInt(r.impressions) || 0;
    const clicks = parseInt(r.clicks) || 0;
    const conversions = parseInt(r.conversions) || 0;
    const campaign = campaignMap[r.campaignId];
    return {
      campaignId: r.campaignId,
      campaignName: campaign?.name,
      bidStrategy: campaign?.bidStrategy,
      status: campaign?.status,
      impressions, clicks, conversions,
      spent: parseFloat(spent.toFixed(2)),
      revenue: parseFloat(revenue.toFixed(2)),
      profit: parseFloat((revenue - spent).toFixed(2)),
      ctr: impressions > 0 ? parseFloat(((clicks / impressions) * 100).toFixed(4)) : 0,
      cpc: clicks > 0 ? parseFloat((spent / clicks).toFixed(4)) : 0,
      cpa: conversions > 0 ? parseFloat((spent / conversions).toFixed(2)) : 0,
      roi: spent > 0 ? parseFloat((((revenue - spent) / spent) * 100).toFixed(2)) : 0,
    };
  });
}
