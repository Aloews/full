import { Router } from 'express';
import { authMiddleware } from '../../middleware/auth';
import { apiLimiter } from '../../middleware/rateLimiter';
import {
  stats,
  performance,
  topCampaigns,
  creativePerformance,
  aiInsights,
  compare,
  rtbStats,
  range,
} from './analytics.controller';

const router = Router();
router.use(authMiddleware, apiLimiter);

// Dashboard
router.get('/stats', stats);

// Campaign analytics
router.get('/performance', performance);       // time-series with groupBy
router.get('/top-campaigns', topCampaigns);    // top N by profit
router.post('/compare', compare);              // side-by-side campaign comparison
router.get('/rtb/:campaignId', rtbStats);      // win rate, avg bid, clearing price

// Creative analytics
router.get('/creatives', creativePerformance); // creative performance ranked by metric

// AI
router.get('/insights', aiInsights);           // GPT-4o analysis + recommendations

// Legacy
router.get('/range', range);

export default router;
