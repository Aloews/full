import { AppDataSource } from '../../config/database';
import { Campaign } from '../../entities/Campaign';
import { AppError } from '../../middleware/errorHandler';
import { CreateCampaignDto, UpdateCampaignDto, PaginationDto } from './campaigns.schemas';

const repo = () => AppDataSource.getRepository(Campaign);

export async function getCampaigns(
  userId: string,
  pagination: PaginationDto
): Promise<{ data: Campaign[]; total: number; page: number; totalPages: number }> {
  const { page, limit, status } = pagination;

  const where: Record<string, any> = { userId };
  if (status) where.status = status;

  const [data, total] = await repo().findAndCount({
    where,
    order: { createdAt: 'DESC' },
    skip: (page - 1) * limit,
    take: limit,
  });

  return { data, total, page, totalPages: Math.ceil(total / limit) };
}

export async function getCampaignById(id: string, userId: string): Promise<Campaign> {
  const campaign = await repo().findOne({ where: { id, userId } });
  if (!campaign) throw new AppError('Campaign not found', 404);
  return campaign;
}

export async function createCampaign(dto: CreateCampaignDto, userId: string): Promise<Campaign> {
  const campaign = repo().create({ ...dto, userId });
  return repo().save(campaign);
}

export async function updateCampaign(
  id: string,
  userId: string,
  dto: UpdateCampaignDto
): Promise<Campaign> {
  const campaign = await getCampaignById(id, userId);
  Object.assign(campaign, dto);
  return repo().save(campaign);
}

export async function deleteCampaign(id: string, userId: string): Promise<void> {
  const campaign = await getCampaignById(id, userId);
  await repo().remove(campaign);
}
