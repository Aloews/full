import { Router } from 'express';
import { authMiddleware } from '../../middleware/auth';
import { validate } from '../../middleware/validate';
import { apiLimiter } from '../../middleware/rateLimiter';
import { createCampaignSchema, updateCampaignSchema } from './campaigns.schemas';
import { list, getOne, create, update, remove } from './campaigns.controller';

const router = Router();
router.use(authMiddleware, apiLimiter);

router.get('/', list);
router.post('/', validate(createCampaignSchema), create);
router.get('/:id', getOne);
router.patch('/:id', validate(updateCampaignSchema), update);
router.delete('/:id', remove);

export default router;
