import { z } from 'zod';

export const createCampaignSchema = z.object({
  name: z.string().min(1, 'Campaign name is required'),
  description: z.string().optional(),
  totalBudget: z.number().positive('Budget must be a positive number'),
  bidStrategy: z.enum(['ROI_OPTIMIZED', 'CPA', 'CPM', 'CPC']).default('ROI_OPTIMIZED'),
  targeting: z.record(z.any()).default({}),
  trafficSources: z.array(z.record(z.any())).default([]),
  status: z.enum(['paused', 'active', 'completed']).default('paused'),
});

export const updateCampaignSchema = createCampaignSchema.partial();

export const paginationSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  status: z.enum(['paused', 'active', 'completed']).optional(),
});

export type CreateCampaignDto = z.infer<typeof createCampaignSchema>;
export type UpdateCampaignDto = z.infer<typeof updateCampaignSchema>;
export type PaginationDto = z.infer<typeof paginationSchema>;
