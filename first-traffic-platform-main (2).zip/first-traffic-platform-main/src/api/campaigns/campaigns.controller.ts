import { Response, NextFunction } from 'express';
import { AuthRequest } from '../../middleware/auth';
import {
  getCampaigns,
  getCampaignById,
  createCampaign,
  updateCampaign,
  deleteCampaign,
} from './campaigns.service';
import { paginationSchema } from './campaigns.schemas';

export async function list(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const pagination = paginationSchema.parse(req.query);
    const result = await getCampaigns(req.user!.id, pagination);
    res.json(result);
  } catch (err) {
    next(err);
  }
}

export async function getOne(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const campaign = await getCampaignById(req.params.id, req.user!.id);
    res.json(campaign);
  } catch (err) {
    next(err);
  }
}

export async function create(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const campaign = await createCampaign(req.body, req.user!.id);
    res.status(201).json(campaign);
  } catch (err) {
    next(err);
  }
}

export async function update(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const campaign = await updateCampaign(req.params.id, req.user!.id, req.body);
    res.json(campaign);
  } catch (err) {
    next(err);
  }
}

export async function remove(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    await deleteCampaign(req.params.id, req.user!.id);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
}
