import jwt from 'jsonwebtoken';
import bcryptjs from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { AppDataSource } from '../../config/database';
import { User } from '../../entities/User';
import { AppError } from '../../middleware/errorHandler';
import { RegisterDto, LoginDto } from './auth.schemas';

const userRepository = () => AppDataSource.getRepository(User);

function generateToken(user: User): string {
  const secret = process.env.JWT_SECRET || 'secret';
  const expiresIn = (process.env.JWT_EXPIRES_IN || '7d') as any;
  return jwt.sign(
    { id: user.id, email: user.email },
    secret,
    { expiresIn }
  );
}

export async function registerUser(dto: RegisterDto) {
  const repo = userRepository();

  const existing = await repo.findOne({ where: { email: dto.email } });
  if (existing) {
    throw new AppError('User with this email already exists', 409);
  }

  const hashedPassword = await bcryptjs.hash(dto.password, 12);
  const user = repo.create({
    email: dto.email,
    password: hashedPassword,
    fullName: dto.fullName,
    apiKey: uuidv4(),
  });

  await repo.save(user);
  const token = generateToken(user);
  return { token, user: { id: user.id, email: user.email, fullName: user.fullName } };
}

export async function loginUser(dto: LoginDto) {
  const repo = userRepository();

  const user = await repo.findOne({ where: { email: dto.email } });
  if (!user) throw new AppError('Invalid credentials', 401);

  const valid = await bcryptjs.compare(dto.password, user.password);
  if (!valid) throw new AppError('Invalid credentials', 401);

  const token = generateToken(user);
  return { token, user: { id: user.id, email: user.email, fullName: user.fullName } };
}
