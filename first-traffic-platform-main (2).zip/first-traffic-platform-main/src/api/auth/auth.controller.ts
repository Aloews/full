import { Response, NextFunction } from 'express';
import { AuthRequest } from '../../middleware/auth';
import { registerUser, loginUser } from './auth.service';
import { RegisterDto, LoginDto } from './auth.schemas';

export async function register(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const result = await registerUser(req.body as RegisterDto);
    res.status(201).json(result);
  } catch (err) {
    next(err);
  }
}

export async function login(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const result = await loginUser(req.body as LoginDto);
    res.json(result);
  } catch (err) {
    next(err);
  }
}
