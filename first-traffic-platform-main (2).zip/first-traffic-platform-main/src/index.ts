import 'reflect-metadata';
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import path from 'path';
import { AppDataSource } from './config/database';
import { redisClient } from './config/redis';
import authRoutes from './api/auth/routes';
import campaignRoutes from './api/campaigns/routes';
import rtbRoutes from './api/rtb/routes';
import analyticsRoutes from './api/analytics/routes';
import creativesRoutes from './api/creatives/routes';
import trafficRoutes from './api/traffic/routes';
import { errorHandler } from './middleware/errorHandler';
import { requestLogger } from './middleware/requestLogger';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com', 'https://fonts.gstatic.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'"],
    },
  },
}));

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(requestLogger);

// Serve static dashboard
app.use(express.static(path.join(__dirname, '..', 'public')));

// Health check
app.get('/health', async (_req, res) => {
  const dbOk = AppDataSource.isInitialized;
  let redisOk = false;
  try { await redisClient.ping(); redisOk = true; } catch {}
  res.json({ status: dbOk ? 'ok' : 'degraded', db: dbOk, redis: redisOk, timestamp: new Date().toISOString() });
});

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/campaigns', campaignRoutes);
app.use('/api/rtb', rtbRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/creatives', creativesRoutes);
app.use('/api/traffic', trafficRoutes);

// SPA fallback
app.get(/^(?!\/api).*/, (_req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

app.use(errorHandler);

AppDataSource.initialize()
  .then(() => {
    console.log('\u2705 Database connected');
    app.listen(PORT, () => {
      console.log(`\ud83d\ude80 Server running on port ${PORT}`);
      console.log(`\ud83c\udf0d Environment: ${process.env.NODE_ENV}`);
    });
  })
  .catch((err: Error) => {
    console.error('\u274c Database connection failed:', err.message);
    process.exit(1);
  });
